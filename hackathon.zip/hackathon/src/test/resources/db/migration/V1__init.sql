/*
 * Initial schema creation
 */
CREATE TABLE users (
    id NUMBER(38) NOT NULL,
    version NUMBER(38) NOT NULL,
    user_name varchar2(256),
    CONSTRAINT users_pkey PRIMARY KEY (id)
);
