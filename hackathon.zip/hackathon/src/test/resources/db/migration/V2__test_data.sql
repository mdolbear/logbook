/*
 * Initial test data
 */

insert into users (id, version, user_name) values (1, 0, 'me');
