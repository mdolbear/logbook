package com.empower.hackathon;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
@Slf4j
class HackathonApplicationTests {

	@Getter(AccessLevel.PRIVATE)
	@Autowired
	private JdbcTemplate jdbcTemplate;


	@Test
	void contextLoads() {
	}


	@Test
	public void testDataCreation() {

		List<String> tempResults;

		tempResults = this.getJdbcTemplate().query("select * from users", new UserRowMapper());
		log.info("Users " + tempResults);

	}
}
