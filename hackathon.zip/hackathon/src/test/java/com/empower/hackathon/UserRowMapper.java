package com.empower.hackathon;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRowMapper implements RowMapper<String> {
    @Override
    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
        String tempResult = null;
        tempResult = rs.getString(3);
        return tempResult;
    }
}
